tyrant_optimize
===============